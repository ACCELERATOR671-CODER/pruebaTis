<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

class SubirPDFController extends Controller
{
    function index_view()
    {
        return view('subirPDF');
    }
}
