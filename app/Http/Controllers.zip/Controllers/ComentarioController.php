<?php

namespace App\Http\Controllers;



class ComentarioController extends Controller
{
    function index_view()
    {
        return view('comentario');
    }
}

