

<?php $__env->startSection('titulo'); ?> 
    Registro Grupo Empresa
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const token = sessionStorage.getItem('token');
    if(token){
        const data = new FormData();
        data.append('token', token);
        fetch("api/verificarSession", {
            method: 'POST',
            body:data
        }).then((response) => {
            return response.json();
        }).then((json) => {
            if(Object.keys(json).length < 1){
                sessionStorage.clear();
                location.replace('Login');
            }
        });
    } else {
        location.replace('Login');
    }
    
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div id='regGE'></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.plantillaprincipal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Proyectos\php7.3\empresaTis\resources\views/registroGE.blade.php ENDPATH**/ ?>