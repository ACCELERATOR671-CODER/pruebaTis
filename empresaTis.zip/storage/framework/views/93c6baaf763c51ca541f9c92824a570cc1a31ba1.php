

<?php $__env->startSection('titulo'); ?> 
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div id="fundaempresa"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.plantillaprincipal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Proyectos\php7.3\empresaTis\resources\views/fundaEmpresa.blade.php ENDPATH**/ ?>