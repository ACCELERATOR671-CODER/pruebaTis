

<?php $__env->startSection('titulo'); ?> 
    Login
<?php $__env->stopSection(); ?>

<?php $__env->startSection('script'); ?>
<script>
    const token = sessionStorage.getItem('token');
    if(!token){
        const data = new FormData();
        data.append('token', token);
        fetch("api/verificarSession", {
            method: 'POST',
            body:data
        }).then((response) => {
            return response.json();
        }).then((json) => {
            if(!Object.keys(json).length < 1){
                sessionStorage.clear();
                location.replace('/');
            }
        });
    } else {
        location.replace('/');
    }
    
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('contenido'); ?>
    <div id="login"></div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.plantillaprincipal', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH F:\Proyectos\php7.3\empresaTis\resources\views/login.blade.php ENDPATH**/ ?>