<?php

use Illuminate\Database\Migrations\Migration;
use Illuminate\Database\Schema\Blueprint;
use Illuminate\Support\Facades\Schema;

class Elemento extends Migration
{
    /**
     * Run the migrations.
     *
     * @return void
     */
    public function up()
    {
        Schema::create('Elemento', function (Blueprint $table) {
            $table->bigIncrements('idElemento');
            $table->string('nombre');
            $table->string('tipo');
            $table->string('link')->nullable;
            $table->integer('idPadre')->nullable();
            $table->foreign('idPadre')->references('idElemento')->on('Elemento');
            $table->integer('idGE');
            $table->foreign('idGE')->references('idGE')->on('Grupo_Empresa');
        });
    }

    /**
     * Reverse the migrations.
     *
     * @return void
     */
    public function down()
    {
        //
    }
}
