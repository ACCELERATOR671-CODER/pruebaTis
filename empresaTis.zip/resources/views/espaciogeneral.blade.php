@extends('templates.plantillaprincipal')

@section('titulo') 
    Login
@endsection

@section('contenido')
    <div id="espaciogeneral"></div>
@endsection