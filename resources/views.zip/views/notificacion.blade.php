<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <meta http-equiv="X-UA-Compatible" content="ie=edge">
    
    
    <title>Document</title>
</head>
<body style="text-align: center">
    <div  style="text-align: center; color:black; border-style: solid; border-color:black; max-width:700px;margin:20px; padding:10px">
        <h1>BIENVENIDO AL SISTEMA DE APOYO DE LA EMPRESA TIS</h1>
        
        <p>
            Bienvenido, ud. ha sido registrado en la plataforma de apoyo a la <strong>empresa TIS</strong> . <br>
            <strong>La empresa TIS</strong> , tiene como mision realizar consultorias para la mejora de<br>
            procesos de desarrollo de software. Con este objetivo, trabaja directamente con<br>
            las empresas consultadas y su equipo en la prestacion de servicios de ingenieria<br>
            de software relativo a un producto software (sistema).<br><br>
            
            El sistema registra usuarios y consultores separándolo en grupos con un consultor<br>
            respectivo, donde el consultor podrá postear Invitaciones, Convocatorias y Requerimientos<br>
            para que los usuarios normales puedan crear Grupo Empresas con no más de 5<br>
            integrantes, ser validadas por el consultor y crear un espacio de trabajo de cada Grupo<br>
            Empresa donde podran postear links, carpetas y documentos para su revisión.<br>
            A su vez el consultor podrá revisar cada documentación posteada, generar contrato una vez<br>
            validadas las Grupo Empresas y postearlas en los espacios de trabajo respectivamente<br><br>
            <h3>
                Para comenzar, puede registrarse con su codigo SIS presionando 
                <a href="http://mythical.tis.cs.umss.edu.bo/RegistroDeUsuario">aqui </a>
            </h3>
        </p>
  
    </div>
</body>
</html>