@extends('templates.plantillaprincipal')

@section('titulo') 
    Espacio General
@endsection



@section('contenido')
    <div id="espaciogeneral"></div>
@endsection