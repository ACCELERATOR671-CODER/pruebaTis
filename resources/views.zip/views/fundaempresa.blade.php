@extends('templates.plantillaprincipal')

@section('titulo') 
    Login
@endsection

@section('contenido')
    <div id="fundaempresa"></div>
@endsection