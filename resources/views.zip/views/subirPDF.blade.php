@extends('templates.plantillaprincipal')

@section('titulo')
    Subir documento PDF
@endsection

@section('contenido')
    <div id='subirPDF'></div>
@endsection
