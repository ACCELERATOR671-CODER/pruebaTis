import React from 'react'
import PropTypes from 'prop-types'

const ComponenteLateral = (src, items) => {
    return (
        <div>
            
        </div>
    )
}

ComponenteLateral.propTypes = {

}

export default ComponenteLateral
