import React from 'react';

import { Pdf_style } from '../../elementos/pdf_style';

const PDFComponent = () => {
    return (

        <>
            <div className="row">
                <div className="col-2">icono</div>
                <div className="col-4">pdf titulo</div>
                <div className="col-6">guardar y cancelar botones</div>
            </div>
        </>
    );
};

export default PDFComponent
