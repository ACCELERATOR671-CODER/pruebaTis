import styled from "styled-components";

const PanelAdmin = styled.div`
    width: 100%;
    padding: 20px;
    display: grid;
    justify-content: center;
    gap : 20px;
`;

export {PanelAdmin};