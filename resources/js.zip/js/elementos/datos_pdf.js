


const Datos = [
    {
        nombre: 'FundaEmpresa',
        link: "#"
    }, {
        nombre: 'Informacion',
        link: "#"
    }
];

export {
    Datos
};
