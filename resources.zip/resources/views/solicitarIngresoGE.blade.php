@extends('templates.plantillaprincipal')

@section('titulo')
    Ingresar a una grupo empresa
@endsection

@section('contenido')
    <div id='solicitarIngresoGE'></div>
@endsection
