@extends('templates.plantillaprincipal')

@section('titulo') 
    Contrato
@endsection



@section('contenido')
    <div id="contrato"></div>
@endsection