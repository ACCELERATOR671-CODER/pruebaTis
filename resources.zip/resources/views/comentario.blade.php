@extends('templates.plantillaprincipal')

@section('titulo')
    Comentarios
@endsection

@section('contenido')
    <div id='comentario'></div>
@endsection
