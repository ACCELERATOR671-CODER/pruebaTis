@extends('templates.plantillaprincipal')

@section('titulo')
    Vista solicitudes de ingreso a grupo empresa
@endsection

@section('contenido')
    <div id='verSolicitudIngresoGE'></div>
@endsection
